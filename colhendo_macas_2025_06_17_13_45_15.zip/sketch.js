let basket;
let apples = [];
let score = 0;
let playing = false;
let playButton;

function setup() {
  createCanvas(400, 400);
  basket = new Basket();+

  //referencias: chatgpt e google
  playButton = createButton("Jogar");
  playButton.position(150, 240); // posição fixa 
  playButton.mousePressed(startGame);
}

function draw() {
  background(200, 240, 255);

  if (!playing) {
    showInstructions();
    return;
  }

  basket.move();
  basket.show();

  for (let i = apples.length - 1; i >= 0; i--) {
    apples[i].fall();
    apples[i].show();

    if (apples[i].caught(basket)) {
      apples.splice(i, 1);
      score++;
    } else if (apples[i].offScreen()) {
      apples.splice(i, 1);
    }
  }

  if (random(1) < 0.02) {
    apples.push(new Apple());
  }

  //pontuação
  fill(0);
  textSize(20);
  text("Pontos: " + score, 10, 30);
}

function showInstructions() {
  textAlign(CENTER);
  fill(0);
  textSize(24);
  text(" Jogo da Colheita de Maçãs ", width / 2, height / 2 - 60);
  textSize(16);
  text("Use as setas ← → para mover a cesta", width / 2, height / 2 - 30);
  text("Pegue as maçãs e ganhe pontos", width / 2, height / 2);
  text("Clique em 'Jogar' para começar", width / 2, height / 2 + 20);
}

function startGame() {
  playing = true;
  playButton.hide(); // Esconde o botão depois que começa
}

function keyPressed() {
  if (playing) {
    if (keyCode === LEFT_ARROW) {
      basket.direction = -1;
    } else if (keyCode === RIGHT_ARROW) {
      basket.direction = 1;
    }
  }
}

function keyReleased() {
  if (playing) {
    basket.direction = 0;
  }
}

class Basket {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.size = 60;
    this.direction = 0;
  }

  move() {
    this.x += this.direction * 5;
    this.x = constrain(this.x, 0, width - this.size);
  }

  show() {
    fill(150, 100, 50);
    rect(this.x, this.y, this.size, 20);
  }
}

class Apple {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 20;
    this.speed = 3;
  }

  fall() {
    this.y += this.speed;
  }

  show() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.size);
  }

  caught(basket) {
    return this.y + this.size / 2 > basket.y &&
           this.x > basket.x &&
           this.x < basket.x + basket.size;
  }

  offScreen() {
    return this.y > height;
  }
}

